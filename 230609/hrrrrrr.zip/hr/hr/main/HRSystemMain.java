package hr.main;

import java.util.Scanner;

import hr.dao.HRSystemDAO;

public class HRSystemMain {

	private Scanner sc;
	private HRSystemDAO hrsdao;
	
	public void dragonMain() {
		System.out.println("______  _____  _   _ ______  _      _____  ______ ______   ___   _____  _____  _   _ ");
		System.out.println("|  _  \\|  _  || | | || ___ \\| |    |  ___| |  _  \\| ___ \\ / _ \\ |  __ \\|  _  || \\ | |");
		System.out.println("| | | || | | || | | || |_/ /| |    | |__   | | | || |_/ // /_\\ \\| |  \\/| | | ||  \\| |");
		System.out.println("| | | || | | || | | || ___ \\| |    |  __|  | | | ||    / |  _  || | __ | | | || . ` |");
		System.out.println("| |/ / \\ \\_/ /| |_| || |_/ /| |____| |___  | |/ / | |\\ \\ | | | || |_\\ \\\\ \\_/ /| |\\  |");
		System.out.println("|___/   \\___/  \\___/ \\____/ \\_____/\\____/  |___/  \\_| \\_|\\_| |_/ \\____/ \\___/ \\_| \\_/");
		
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            Main           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    1. 로그인     2. 시스템 종료   ");
		System.out.println();
		System.out.println("    💡 선택(숫자 입력) >> ");
	   	System.out.println();
	   	System.out.println("--------------------------------");
	   	System.out.println("    1번이나 2번을 선택하세요.     ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
	   	
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        SYSTEM EXIT        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 시스템을 종료하시겠습니까? ( Y | N )");
		System.out.println("  💡 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("     시스템이 종료되었습니다.     ");
		System.out.println("--------------------------------");
	}
	
	public void login() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║           LOGIN           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    💡 아이디 >>  ");
		System.out.println();
		System.out.println("    💡 비밀번호 >>  ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("  잘못된 입력입니다. 다시 입력해주세요  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	public void pwChange() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║      Change Password      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 변경할 비밀번호 입력 (숫자 4자리) >");
	    System.out.println("  💡>> ");
	    System.out.println("--------------------------------");
	    System.out.println("     비밀번호 변경이 완료되었습니다.   ");
	    System.out.println("--------------------------------");
	    System.out.println("--------------------------------");
	    System.out.println(" 비밀번호 변경에 실패했습니다. 다시 입력해주세요.");
	    System.out.println("--------------------------------");
	    System.out.println();
		
	}
	
	
	public void main(String emid[]) {
		
	}
	
	
}
