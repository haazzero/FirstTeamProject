package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import hr.vo.YearVO;

public class YearDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean yearInsert(YearVO emid) {
	return false;
      
   }
   
   public List<YearVO> yearSelecet() {
	return null;
      
   }
   
   public List<YearVO> yearSelect(String emid) {
	return null;
      
   }
   
   public YearVO yearSelect(int emno) {
	return null;
	   
   }
   
   public boolean yearUpdate(YearVO emid) {
	return false;
      
   }
   
   public boolean yeardelete(String emid) {
	return false;
      
   }
      
}