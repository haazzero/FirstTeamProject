package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import hr.vo.EmployeeVO;

public class EmployeeDAO {

	private String query;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean emInsert(EmployeeVO emid) {
		return false;
		
	}
	
	public List<EmployeeVO> emSelect() {
		return null;
		
	}
	
	public List<EmployeeVO> emSelectD(String emid) {
		return null;
		
	}
	
	
	public List<EmployeeVO> emSelectP(String emid) {
		return null;
		
	}
	
	public EmployeeVO emSelect(String emid) {
		return null;
		
	}
	
	public boolean emUpdate(EmployeeVO emid) {
		return false;
		
	}
	
	public boolean emDelete(String emid) {
		return false;
		
	}
	
}
