package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import hr.vo.ReviewVO;

public class ReviewDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean revInsert(ReviewVO rid) {
	return false;
      
   }
   
   public List<ReviewVO> revSelect() {
	return null;
      
   }
   
   public List<ReviewVO> revSelectD(String rid) {
	return null;
      
   }
   
   public List<ReviewVO> revSelectP(String rid) {
	return null;
      
   }
   
   public List<ReviewVO> revSelectY(String rid) {
	return null;
      
   }
   
   public List<ReviewVO> revSelect(String rid) {
	return null;
      
   }
   
   public ReviewVO revSelect(int rno) {
	return null;
	   
   }
   
   public boolean revUpdate(ReviewVO rid) {
	return false;
      
   }
   
   public boolean revDelete(String rid) {
	return false;
      
   }
   
}