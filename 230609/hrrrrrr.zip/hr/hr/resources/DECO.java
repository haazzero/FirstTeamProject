package hr.resources;

public class DECO {
	
	

	public static void dragon() {
		System.out.println("______  _____  _   _ ______  _      _____  ______ ______   ___   _____  _____  _   _ ");
		System.out.println("|  _  \\|  _  || | | || ___ \\| |    |  ___| |  _  \\| ___ \\ / _ \\ |  __ \\|  _  || \\ | |");
		System.out.println("| | | || | | || | | || |_/ /| |    | |__   | | | || |_/ // /_\\ \\| |  \\/| | | ||  \\| |");
		System.out.println("| | | || | | || | | || ___ \\| |    |  __|  | | | ||    / |  _  || | __ | | | || . ` |");
		System.out.println("| |/ / \\ \\_/ /| |_| || |_/ /| |____| |___  | |/ / | |\\ \\ | | | || |_\\ \\\\ \\_/ /| |\\  |");
		System.out.println("|___/   \\___/  \\___/ \\____/ \\_____/\\____/  |___/  \\_| \\_|\\_| |_/ \\____/ \\___/ \\_| \\_/");
	}
	
	public static void dragon2() {
		System.out.println("####      ####    ##  ##   #####    ##       ######   ####     #####     ####     ####     ####    ##  ##");
		System.out.println("## ##    ##  ##   ##  ##   ##  ##   ##       ##       ## ##    ##  ##   ##  ##   ##  ##   ##  ##   ### ##");
		System.out.println("##  ##   ##  ##   ##  ##   ##  ##   ##       ##       ##  ##   ##  ##   ##  ##   ##       ##  ##   ######");
		System.out.println("##  ##   ##  ##   ##  ##   #####    ##       ####     ##  ##   #####    ######   ## ###   ##  ##   ######");
		System.out.println("##  ##   ##  ##   ##  ##   ##  ##   ##       ##       ##  ##   ####     ##  ##   ##  ##   ##  ##   ## ###  ");
		System.out.println("## ##    ##  ##   ##  ##   ##  ##   ##       ##       ## ##    ## ##    ##  ##   ##  ##   ##  ##   ##  ##  ");
		System.out.println("####      ####     ####    #####    ######   ######   ####     ##  ##   ##  ##    ####     ####    ##  ##  ");
	}
	
	public static void tableform1() {
		System.out.println("╔═══════════════════════════╗");
		System.out.println("║                           ║");
		System.out.println("║                           ║");
		System.out.println("║                           ║");
		System.out.println("║                           ║");
		System.out.println("╚═══════════════════════════╝");
	}

	public static void tableform2() {
		System.out.println("┌──────────────────────────┐");
		System.out.println("│                          │");
		System.out.println("│                          │");
		System.out.println("│                          │");
		System.out.println("│                          │");
		System.out.println("└──────────────────────────┘");
		
	}

	public static void tableform3() {
		System.out.println("╔═════════════╦═════════════╗");
		System.out.println("╠═════════════╩═════════════║");
		System.out.println("║                           ║");
		System.out.println("║                           ║");
		System.out.println("║                           ║");
		System.out.println("╚═══════════════════════════╝");
	}
	
	public static void tableform4() {
		System.out.println("┌───────┬───────┬─────────┬─────┐");
		System.out.println("│       │       │         │     │");
		System.out.println("├───────┼───────┼─────────┼─────┤");
		System.out.println("│       │       │         │     │");
		System.out.println("└───────┴───────┴─────────┴─────┘");
		
	}

	public static void tableform5() {
		System.out.println("┌───────┬───────┬─────────┬─────┐");
		System.out.println("│       │       │         │     │");
		System.out.println("└───────┴───────┴─────────┴─────┘");
	}
	
	public static void tableform6() {

		System.out.println("╔══════╦══════════╦═════╦════╗");
		System.out.println("║      ║          ║     ║    ║");
		System.out.println("╠══════╬══════════╬═════╬════╣");
		System.out.println("║      ║          ║     ║    ║");
		System.out.println("╚══════╩══════════╩═════╩════╝");
	}
	
	public static void tableform7() {
		
		
	}
	
	public static void main(String[] args) {
	
//System.out.println("│ ─ ┌ ┐└ ┘├ ┤┬ ┴ ┼ ═║╒╓╔ ╕╖╗╘ ╙ ╚ ╛╜╝╞ ╟ ╠ ╡╢╣ ╤ ╥ ╦ ╧ ╨ ╩ ╪ ╫ ╬ ╬");
		System.out.println();
		


	}

}
