package hr.vo;

import java.util.Date;

public class HistoryVO {
	private String emid;		//	������ȣ emid : String
	private String name;		//	�����̸� name : String
	private String deno;		//	�� �μ� deno : String
//	private Date departStart;	//	�μ���ϳ�¥ departStart : date
//	private Date departMove;	//	�μ��̵���¥ departMove : date
//	private String position;	//	�� ���� position : String
//	private Date revom;			//	���� ��¥ revom : date
	private Date leaveStart; 	//	�������۳�¥ leaveStart : date
	private Date leaveFin;		//	�������ᳯ¥ leaveFin : date
	private String remark;		//	���� reamark : String
	public String getEmid() {
		return emid;
	}
	public void setEmid(String emid) {
		this.emid = emid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDeno() {
		return deno;
	}
	public void setDeno(String deno) {
		this.deno = deno;
	}
	public Date getLeaveStart() {
		return leaveStart;
	}
	public void setLeaveStart(Date leaveStart) {
		this.leaveStart = leaveStart;
	}
	public Date getLeaveFin() {
		return leaveFin;
	}
	public void setLeaveFin(Date leaveFin) {
		this.leaveFin = leaveFin;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
}