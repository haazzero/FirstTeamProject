package hr.vo;

public class WorkVO {
	private String emid; 		//	������ȣ emid : String
	private String name;		//	�����̸� name : String
	private int cont;			//	�ټӳ�� cont : int
	private int late;			//	�����ϼ� late : int
	private int early;			//	�����ϼ� early : int
	private int abs;			//	����ϼ� abs : int
	private int avAnn;			//	��밡�ɿ����ϼ� avAnn : int
	private int usedAnn;		//	��뿬���ϼ� usedAnn : int
	private int unusedAnn;		//	�ܿ������ϼ� unusedAnn : int
	
	public String getEmid() {
		return emid;
	}
	public void setEmid(String emid) {
		this.emid = emid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCont() {
		return cont;
	}
	public void setCont(int cont) {
		this.cont = cont;
	}
	public int getLate() {
		return late;
	}
	public void setLate(int late) {
		this.late = late;
	}
	public int getEarly() {
		return early;
	}
	public void setEarly(int early) {
		this.early = early;
	}
	public int getAbs() {
		return abs;
	}
	public void setAbs(int abs) {
		this.abs = abs;
	}
	public int getAvAnn() {
		return avAnn;
	}
	public void setAvAnn(int avAnn) {
		this.avAnn = avAnn;
	}
	public int getUsedAnn() {
		return usedAnn;
	}
	public void setUsedAnn(int usedAnn) {
		this.usedAnn = usedAnn;
	}
	public int getUnusedAnn() {
		return unusedAnn;
	}
	public void setUnusedAnn(int unusedAnn) {
		this.unusedAnn = unusedAnn;
	}
	
	
	
	
	
}