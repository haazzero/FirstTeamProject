package hr.vo;

public class SalaryInfoVO {

	private String emid;		//	������ȣ emid : String
	private String name;		//	�����̸� name : String
	private int sal;            //  �⺻�� sal : int
	private String bank;		//	����� bank : String
	private String depositor;	//	������ depositor : String
	private String account;		//	���¹�ȣ account : String
	
	public String getEmid() {
		return emid;
	}
	public void setEmid(String emid) {
		this.emid = emid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getDepositor() {
		return depositor;
	}
	public void setDepositor(String depositor) {
		this.depositor = depositor;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	
	
	
}