package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import hr.vo.HRSystemVO;

public class HRSystemDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean pwUpdate(HRSystemVO mid) {
	return false;
      
   }
   
   public boolean loginCheck(String mlog, String mlogin) {
	return false;
	   
   }
   
   
   
}