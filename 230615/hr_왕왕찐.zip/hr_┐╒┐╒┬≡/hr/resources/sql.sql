CREATE VIEW tview AS
SELECT t_member.mid, mname, memo, reg_date
FROM t_member, t_memo
WHERE t_member.mid = t_memo.mid;
