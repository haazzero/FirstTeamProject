package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBConn {

	private static Connection con;
	
	private DBConn() {}
	
	public static Connection getConnection() {
		return con;
		
	}
	
	public static void close(PreparedStatement pstmt) {
		
	}
	
	public static void close(PreparedStatement pstmt, ResultSet rs) {
		
	}
	
	
	
}
