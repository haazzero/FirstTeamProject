package main;

import java.util.Scanner;

import dao.EmployeeDAO;
import dao.HistoryDAO;
import dao.ReviewDAO;
import dao.SalaryInfoDAO;
import dao.SalaryPaymentDAO;
import dao.WorkDAO;
import dao.YearDAO;

public class HrReadMain {

	private Scanner sc;
	public static String id;
	private EmployeeDAO edao;
	private HistoryDAO hdao;
	private WorkDAO wdao;
	private YearDAO ydao;
	private SalaryInfoDAO sdao;
	private SalaryPaymentDAO spdao;
	private ReviewDAO rdao;

	public void pmReader() {
		
	}
	
	public void emView() {
		
	}
	
	public void emList() {
		
	}
	
	public void emDtail(String emid) {
		
	}
	
	public void hisAllList() {
	}
	
	public void hisList(String emid) {
		
	}
	
	public void hisDetail() {
		
	}
	
	public void workView() {
		
	}
	
	public void workList() {
		
	}
	
	public void workDetail(String emid) {
		
	}
	
	public void yearAllList() {
		
	}
	
	public void yearList(String emid) {
		
	}
	
	public void yearDetail() {
		
	}
	
	public void salMain() {
		
	}
	
	public void salInfoList() {
		
	}
	
	
	public void salInfoDetail(String emid) {
		
	}
	
	
	public void salPayAllList() {
		
	}
	
	public void salPayList(String emid) {
		
	}
	
	public void salPayDetail() {
		
	}
	
	public void revView() {
		
	}
	
	public void revAllList() {
		
	}
	
	public void revLiet(String emid) {
		
	}
	
	public void revDetail() {
		
	}
		
}