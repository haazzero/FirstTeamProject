package main;

import java.util.Scanner;

import dao.EmployeeDAO;
import dao.HistoryDAO;
import dao.ReviewDAO;
import dao.SalaryInfoDAO;
import dao.SalaryPaymentDAO;
import dao.WorkDAO;
import dao.YearDAO;

public class HrAdminMain {
	
	private Scanner sc;
	public static String id;
	private EmployeeDAO edao;
	private HistoryDAO hdao;
	private WorkDAO wdao;
	private YearDAO ydao;
	private SalaryInfoDAO sdao;
	private SalaryPaymentDAO spdao;
	private ReviewDAO rdao;

	public void pmMenu() {
	}
	
	
	public void emManage() {
		
	}
	
	public void emWrite() {
		
	}
	
	public void emModify(String emid) {
		
	}
	
	public void emRemove(String emid) {
		
	}
	
	public void historyWrite() {
		
	}
	
	public void historyModify(String emid) {
		
	}
	
	public void historyRemove(String emid) {
		
	}
	
	
	public void workManage() {
		
	}
	
	public void workWrite() {
		
	}
	
	public void workModify(String emid) {
		
	}
	
	public void workRemove(String emid) {
		
	}
	
	public void yearWrite() {
		
	}
	
	public void yearModify(String emid) {
	}
	
	public void yearRemove(String emid) {
		
	}
	
	public void revManage() {
		
	}
	
	public void revWrite() {
		
	}
	
	public void revModify(String emid) {
		
	}
	
	public void revRemove(String emid) {
		
	}	
	
	
}
