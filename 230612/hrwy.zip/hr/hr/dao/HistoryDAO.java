package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import hr.util.DBConn;
import hr.vo.HistoryVO;

public class HistoryDAO {

	private String query;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean hisInsert(HistoryVO hvo) {
		query = "INSERT INTO t_memo VALUES (memo_seq.NEXTVAL,?,?,SYSDATE)";

		try {	// DBConn.getConnection()이 Connection을 반환하므로 con 대신 메소드 호출
			pstmt = DBConn.getConnection().prepareStatement(query);	
			//pstmt.setString(1, hvo.getMemo());
			//pstmt.setString(2, hvo.getMid());
			
			int result = pstmt.executeUpdate();	// 실행했을 때 1이 나와야 성공
			if (result == 1) 	// 정상적으로 회원가입 성공 시 true 반환
				return true; 

		} catch (SQLException e) {
			e.printStackTrace();
		}	finally {
			DBConn.close(pstmt);	// con을 생성하지 않았기 때문에 pstmt만 닫음
		}
		return false;			// 그렇지 않으면 false 반환
	}
	
	public List<HistoryVO> hisSelect() {
		List<HistoryVO> hvoList = new ArrayList<>();
		HistoryVO hvo = null;
		try {	
			query = "SELECT * FROM t_memo";
			pstmt = DBConn.getConnection().prepareStatement(query);	
			rs = pstmt.executeQuery();
			while(rs.next()) {			// 조회되는 레코드가 있다면 VO객체를 생성하여 해당 레코드 값을 저장
				hvo = new HistoryVO();	// 레코드를 저장할 객체
				//hvo.setMno(rs.getInt("mno"));
				//hvo.setMemo(rs.getString("memo"));
				//hvo.setMid(rs.getString("mid"));
				//hvo.setRegDate(rs.getDate("reg_date"));
				
				hvoList.add(hvo);		// List 객체에 mvo 데이터 추가
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	finally {
			DBConn.close(rs, pstmt);	// 사용했던 rs, pstmt 순으로 닫음
		}
		return hvoList;
		
	}
	
	public List<HistoryVO> hisSelect(String mid) {
		HistoryVO hvo = null;		// 지역변수는 초기화 필수
		List<HistoryVO> hvoList = new ArrayList<>(); 
		try {	
			query = "SELECT * FROM t_memo WHERE mid = ?";			// 1. SELECT 쿼리문 만들기
			pstmt = DBConn.getConnection().prepareStatement(query);	// 2. pstmt 객체 생성
			pstmt.setString(1, mid);								// 3. 데이터 바인딩
			rs = pstmt.executeQuery();								// 4. 쿼리문 실행
			
			while(rs.next()) {	// 조회되는 레코드가 있다면 VO객체를 생성하여 해당 레코드 값을 저장
				hvo = new HistoryVO();	// 레코드를 저장할 객체
				//hvo.setMno(rs.getInt("mno"));
				//hvo.setMemo(rs.getString("memo"));
				//hvo.setMid(rs.getString("mid"));
				//hvo.setRegDate(rs.getDate("reg_date"));
				hvoList.add(hvo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	finally {
			DBConn.close(rs, pstmt);	// 사용했던 rs, pstmt 순으로 닫음
		}
		return hvoList;	
		
	}
	
	public HistoryVO hisSelect(int mno) {
		HistoryVO hvo = null;		// 지역변수는 초기화 필수
		try {	
			query = "SELECT * FROM t_memo WHERE mno = ?";			// 1. SELECT 쿼리문 만들기
			pstmt = DBConn.getConnection().prepareStatement(query);	// 2. pstmt 객체 생성
			pstmt.setInt(1, mno);									// 3. 데이터 바인딩
			rs = pstmt.executeQuery();								// 4. 쿼리문 실행
			
			while(rs.next()) {	// 조회되는 레코드가 있다면 VO객체를 생성하여 해당 레코드 값을 저장
				hvo = new HistoryVO();	// 레코드를 저장할 객체
				//hvo.setMno(rs.getInt("mno"));
				//hvo.setMemo(rs.getString("memo"));
				//hvo.setMid(rs.getString("mid"));
				//hvo.setRegDate(rs.getDate("reg_date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	finally {
			DBConn.close(rs, pstmt);	// 사용했던 rs, pstmt 순으로 닫음
		}
		return hvo;	
		
	}
	
	public boolean hisUpdate(HistoryVO mid) {
		query = "UPDATE t_memo SET memo = ? WHERE mno = ?";
		try {
			pstmt = DBConn.getConnection().prepareStatement(query);	
			//pstmt.setString(1, memo);		// 매개변수로 받은 memo와 mno를 직접 바인딩
			//pstmt.setInt(2, mno);			// mvo 사용 x
			
			int result = pstmt.executeUpdate();	// 실행했을 때 1이 나와야 성공
			if (result == 1) 	// 정상적으로 업데이트 시 true 반환
				return true; 

		} catch (SQLException e) {	// 예외 처리
			e.printStackTrace();
		} finally {
			DBConn.close(pstmt);	// pstmt만 닫음
		}
		
		return false;				// 실패 시 false 반환
		
	}
	
	
	public boolean hisDelete(String mid) {
		query = "DELETE FROM t_memo WHERE mno = ?";
		try {	
			pstmt = DBConn.getConnection().prepareStatement(query);	
			pstmt.setString(1, mid);	// mvo가 아닌 매개변수 mno 그대로 바인딩
			
			int result = pstmt.executeUpdate();	// 실행했을 때 1이 나와야 성공
			if (result == 1) 	// 정상적으로 삭제 성공 시 true 반환
				return true; 

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstmt);	// pstmt 닫음
		}
		return false;			// 실패 시 false 반환
	}
		
	}
		
