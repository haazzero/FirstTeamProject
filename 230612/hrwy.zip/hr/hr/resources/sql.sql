// work select 전체 목록 쿼리문 -> 직원번호, 직원이름, 지각일수, 조퇴일수, 결근일수, 잔여연차일수 출력
	SELECT employees.emid, name, late, early, abs, unused_ann
	FROM work, employees 
	WHERE work.emid = employees.emid
	ORDER BY work.emid ASC;

// work select 개별 조회 쿼리문 -> 직원번호, 직원이름, 지각일수, 조퇴일수, 결근일수, 사용가능연차일수, 사용한연차일수, 잔여연차일수 출력
	SELECT work.emid, name, late, early, abs, av_ann, used_ann, unused_ann
	FROM WORK, employees
	WHERE work.emid = employees.emid;

// select 개별 조회 시 조인한 테이블에서 특정 값 추출 (on 조인 구문)
	SELECT work.emid, name, late, early, abs, av_ann, used_ann, unused_ann
	FROM WORK INNER JOIN employees
	ON work.emid = employees.emid
	WHERE work.emid = 'D1001';

// 얘도 가능 (where 조인 구문)
	SELECT work.emid, name, late, early, abs, av_ann, used_ann, unused_ann
	FROM WORK, employees
	WHERE work.emid = employees.emid
	AND work.emid = 'D1001';
	
// work update 쿼리문 -> 근속년수, 지각일수, 조퇴일수, 결근일수, 사용가능연차일수, 사용한연차일수, 잔여연차일수 수정
	UPDATE work SET cont = 1, late = 1, early = 1, abs = 1, av_ann = 1, used_ann = 1, unused_ann = 1
	WHERE emid = 'D1001';			// 항목마다 따로 수정하는거 고려하기

// work delete 쿼리문 -> 한 행 삭제
	DELETE FROM work WHERE emid = 'D2002';
	
// year select 전체 목록 쿼리문 -> 직원번호, 직원이름, 연차승인자, 연차승인일자 출력
	SELECT years.emid, name, app, app_date 
	FROM years, employees 
	WHERE employees.emid = years.emid
	ORDER BY years.emid ASC;
	
// year select 개별 조회 쿼리문 -> 직원번호, 직원이름, 연차사용일자, 연차사용일수, 연차승인자, 연차승인일자 출력
	SELECT years_no, years.emid, name, years_date, years_cnt, app, app_date
	FROM years, employees
	WHERE employees.emid = years.emid AND years.emid = 'D1001';	
	
// year select 상세 조회 쿼리문 -> 직원번호, 직원이름, 연차사용일자, 연차사용일수, 연차승인자, 연차승인일자 출력
	SELECT years_no, years.emid, name, years_date, years_cnt, app, app_date
	FROM years, employees
	WHERE employees.emid = years.emid AND years_no = 4;
	
// year update 쿼리문 -> 연차사용일자, 연차사용일수, 연차승인자, 연차승인일자 수정
	UPDATE years SET years_date, years_cnt, app, app_date = '2023-06-11' 
	WHERE years_no = 4;			// 항목마다 따로 수정 고려하기

// year delete 쿼리문 -> 한 행 삭제
	DELETE FROM years WHERE years_no = 5;