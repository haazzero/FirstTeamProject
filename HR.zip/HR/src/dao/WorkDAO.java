package dao;

public class WorkDAO {

	public boolean workInsert(WorkVO) {
		
	}
	
	public List<WorkVO> WorkSelect() {
		
	}
	
	public WorkVO WorkSelect(String) {
		
	}
	
	public boolean WorkUpdate(WorkVO) {
		
	}
	public boolean WorkDelete(String) {
		
	}
	
	
}
