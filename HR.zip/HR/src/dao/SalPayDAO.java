package dao;

public class SalPayDAO {

	public boolean SalPayInsert(SalPayVO) {
	
	}
	
	public List<SalPayVO> SalPaySelect() {
		
	}
	
	public List<SalPayVO> SalPaySelectD() {
		
	}
	
	public SalPayVO SalPaySelect(String) {
		
	}
	
	public boolean SalPayUpdate(SalPayVO) {
		
	}
	
	public boolean SalDelete(SalPayVO) {
		
	}
		
}
