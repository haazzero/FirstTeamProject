package dao;

public class SalaryDAO {

	public boolean SalInsert(SalVO) {
		
	}
	
	public List<salVO> SalSelect() {
		
	}
	
	public List<SalVO> SalSelectD() {
		
	}
	public SalVO SalSelect(SalVO) {
		
	}
	public boolean SalUpdate(SalVO) {
		
	}
	
	public bollean SalDelete(String) {
		
	}
	
}
