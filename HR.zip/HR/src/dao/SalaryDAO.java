package dao;

public class SalaryDAO {

	public boolean salInsert(salVO) {
		
	}
	
	public List<salVO> salSelect() {
		
	}
	
	public List<salVO> salSelectD() {
		
	}
	public salVO salSelect(salVO) {
		
	}
	public boolean salUpdate(salVO) {
		
	}
	
	public boolean salDelete(String) {
		
	}
	
}
