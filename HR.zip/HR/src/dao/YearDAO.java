package dao;

public class YearDAO {

	public boolean YearInsert(YearVO) {
		
	}
	
	public List<YearVO> YearSelecet() {
		
	}
	
	public List<YearVO> YearSelect(YearVO) {
		
	}
	
	public boolean YearUpdate(YearVO) {
		
	}
	
	public boolean Yeardelete(String) {
		
	}
		
}