package dao;

public class YearDAO {

	public boolean yearInsert(yearVO) {
		
	}
	
	public List<yearVO> yearSelecet() {
		
	}
	
	public List<yearVO> yearSelect(yearVO) {
		
	}
	
	public boolean yearUpdate(yearVO) {
		
	}
	
	public boolean yeardelete(String) {
		
	}
		
}