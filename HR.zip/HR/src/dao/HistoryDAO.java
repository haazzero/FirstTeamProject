package dao;

public class HistoryDAO {

	public boolean hisInsert() {
		
	}
	
	public List<hisVO> hisSelect() {
		
	}
	
	public HisVO hisSelect(String) {
		
	}
	
	public boolean hisUpdate(String) {
		
	}
	
	
	public boolean hisDelete(String) {
		
	}
		
}
