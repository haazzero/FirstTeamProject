package dao;

public class HistoryDAO {

	public boolean HisInsert() {
		
	}
	
	public List<HisVO> HisSelect() {
		
	}
	
	public HisVO HisSelect(String) {
		
	}
	
	public boolean HisUpdate(String) {
		
	}
	
	
	public boolean HisDelete(String) {
		
	}
		
}
