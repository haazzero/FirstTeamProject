package dao;

public class HRSystemDAO {

	public boolean pwUpdate(idVO) {
		
	}
	
	
	
}
