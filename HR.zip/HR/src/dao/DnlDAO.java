package dao;

public class DnlDAO {

	public boolean DnlInsert(DnlVO) {
		
	}
	
	public List<DNLVO> DnlSelect() {
		
	}
	public DnlVO DnlSelect(String) {
		
	}
	public boolean DnlUpdate(DnlVO) {
		
	}
	public boolean DnlDelete(String) {
		
	}
	
	
}
