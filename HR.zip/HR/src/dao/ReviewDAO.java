package dao;

public class ReviewDAO {

	public boolean revInsert(revVO) {
		
	}
	
	public List<revVO> revSelecet() {
		
	}
	
	public List<revVO> revSelectD() {
		
	}
	
	public List<revVO> revSelectP() {
		
	}
	
	public List<revVO> revSelectY() {
		
	}
	
	public revVO revSelect(String) {
		
	}
	
	public boolean revUpdate(revVO) {
		
	}
	
	public boolean revDelete(String) {
		
	}
	
}