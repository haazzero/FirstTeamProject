package dao;

public class EmployeeDAO {

	public boolean emInsert(emVO) {
		
	}
	
	public List<emVO> emSelect() {
		
	}
	
	public List<emVO> emSelectD() {
		
	}
	
	
	public List<emVO> emSelectP() {
		
	}
	
	public emVO emSelect(String) {
		
	}
	
	public boolean emUpdate(emVO) {
		
	}
	
	public boolean emDelete(String) {
		
	}
	
}
