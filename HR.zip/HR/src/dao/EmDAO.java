package dao;

public class EmDAO {

	public boolean EmInsert(EmVO) {
		
	}
	
	public List<EmVO> EmSelect() {
		
	}
	
	public List<EmVO> EmSelectD() {
		
	}
	
	
	public List<EmVO> EmSelectP() {
		
	}
	
	public EmVO EmSelect(String) {
		
	}
	
	public boolean EmUpdate(EmVO) {
		
	}
	
	public boolean EmDelete(String) {
		
	}
	
}
