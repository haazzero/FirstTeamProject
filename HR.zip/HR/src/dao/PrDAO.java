package dao;

public class PrDAO {

	public boolean PrInsert() {
		
	}
	
	public List<PrVO> PrSelecet() {
		
	}
	
	public List<PrVO> PrSelectD() {
		
	}
	
	public List<PrVO> PrSelectP() {
		
	}
	
	public List<PrVO> PrSelectY() {
		
	}
	
	public PrVO PrSelect(String) {
		
	}
	
	public boolean PrUpdate(PrVO) {
		
	}
	
	public boolean PrDelete(String) {
		
	}
	
}