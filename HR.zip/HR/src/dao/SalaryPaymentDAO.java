package dao;

public class SalaryPaymentDAO {

	public boolean salPayInsert(salPayVO) {
	
	}
	
	public List<salPayVO> salPaySelect() {
		
	}
	
	public List<salPayVO> salPaySelectD() {
		
	}
	
	public salPayVO salPaySelect(String) {
		
	}
	
	public boolean salPayUpdate(salPayVO) {
		
	}
	
	public boolean salDelete(salPayVO) {
		
	}
		
}
