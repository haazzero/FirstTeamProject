package dao;

public class GeneraDAO {

	public boolean PwUpdate(idVO) {
		
	}
	
	
	
}
