package vo;

public class DnlVO {

}
