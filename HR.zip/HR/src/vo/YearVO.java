package vo;

public class YearVO {

}
