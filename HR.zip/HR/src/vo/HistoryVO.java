package vo;

import java.util.Date;

public class HistoryVO {
	private String emid;		//	������ȣ emid : String
	private String name;		//	�����̸� name : String
	private String depart;		//	�� �μ� depart : String
	private Date departStart;	//	�μ���ϳ�¥ departStart : date
	private Date departMove;	//	�μ��̵���¥ departMove : date
	private String position;	//	�� ���� position : String
	private Date revom;			//	���� ��¥ revom : date
	private Date leaveStart; 	//	�������۳�¥ leaveStart : date
	private Date leaveFin;		//	�������ᳯ¥ leaveFin : date
	private String remark;		//	��� reamark : String
	public String getEmid() {
		return emid;
	}
	public void setEmid(String emid) {
		this.emid = emid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepart() {
		return depart;
	}
	public void setDepart(String depart) {
		this.depart = depart;
	}
	public Date getDepartStart() {
		return departStart;
	}
	public void setDepartStart(Date departStart) {
		this.departStart = departStart;
	}
	public Date getDepartMove() {
		return departMove;
	}
	public void setDepartMove(Date departMove) {
		this.departMove = departMove;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public Date getRevom() {
		return revom;
	}
	public void setRevom(Date revom) {
		this.revom = revom;
	}
	public Date getLeaveStart() {
		return leaveStart;
	}
	public void setLeaveStart(Date leaveStart) {
		this.leaveStart = leaveStart;
	}
	public Date getLeaveFin() {
		return leaveFin;
	}
	public void setLeaveFin(Date leaveFin) {
		this.leaveFin = leaveFin;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
}