package vo;

public class PrVO {

}
