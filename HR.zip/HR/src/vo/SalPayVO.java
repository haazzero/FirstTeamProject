package vo;

public class SalPayVO {

}
