package vo;

public class AuthVO {

}
