package vo;

public class SalVO {

}
