package vo;

import java.util.Date;

public class EmployeeVO {

	private String emid;  		// ������ȣ emid : String
	private String name;		//	�����̸� name : String
	private String position;	//	�μ� position : String
	private String dno;			//	�μ���ȣ dno : String
	private Date birth;			//	������� birth : date
	private String tel;			//	��ȭ��ȣ tel : String
	private String gen;			//	���� gen : String
	private Date join;			//	�Ի����� join : date
	
	
	public String getEmid() {
		return emid;
	}
	public void setEmid(String emid) {
		this.emid = emid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getDno() {
		return dno;
	}
	public void setDno(String dno) {
		this.dno = dno;
	}
	public Date getBirth() {
		return birth;
	}
	public void setBirth(Date birth) {
		this.birth = birth;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getGen() {
		return gen;
	}
	public void setGen(String gen) {
		this.gen = gen;
	}
	public Date getJoin() {
		return join;
	}
	public void setJoin(Date join) {
		this.join = join;
	}
	
	
	
	
	
}