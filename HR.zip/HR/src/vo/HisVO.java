package vo;

public class HisVO {

	
}
