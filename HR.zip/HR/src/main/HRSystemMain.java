package main;

public class HRSystemMain {

	public void dragonMain() {
		
	}
	
	public void login() {
		
	}
	
	public void pwChange() {
		
	}
	
	public void main(String[]) {
		
	}
	
	
}
