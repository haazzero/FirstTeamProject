package main;

public class AadminMain {

	public void AdManage() {
		
	}
	
	public void SalInfo() {
		
	}
	
	public void SalPayMange() {
		
	}
	
	public void SalInfoWrite() {
		
	}
	
	public void SalInfoModify(String) {
		
	}
	
	public void SalInfoRemove(String) {
		
	}
	
	public void SalPayWrite() {
		
	}
	
	public void SalPayModify(String) {
		
	}
	
	public void SalPayRemove(String) {
		
	}
	
}
