package main;

public class HrAdminMain {

	public void PmMenu() {
	}
	
	
	public void EmManage() {
		
	}
	
	public void EmWrite() {
		
	}
	
	public void EmModify(String) {
		
	}
	
	public void EmRemove(String) {
		
	}
	
	public void HisWrite() {
		
	}
	
	public void HisModify(String) {
		
	}
	
	public void HisRemove(String) {
		
	}
	
	
	pulbic void DnlManage() {
		
	}
	
	public void DnlWrite() {
		
	}
	
	public void DnlModify(String) {
		
	}
	
	public void DnlRemove(String) {
		
	}
	
	public void YearWrite() {
		
	}
	
	public void YearModify(String) {
	}
	
	public void YearRemove(String) {
		
	}
	
	public void PrManage() {
		
	}
	
	public void PrWrite() {
		
	}
	
	public void PrModify(String) {
		
	}
	
	public void PrRemove(String) {
		
	}	
	
	
}
