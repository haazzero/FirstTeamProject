package main;

public class AccountAdminMain {

	public void adManage() {
		
	}
	
	public void salInfo() {
		
	}
	
	public void salInfoWrite() {
		
	}
	
	public void salInfoModify(String) {
		
	}
	
	public void salInfoRemove(String) {
		
	}
	
	public void salPayWrite() {
		
	}
	
	public void salPayModify(String) {
		
	}
	
	public void salPayRemove(String) {
		
	}
	
}
