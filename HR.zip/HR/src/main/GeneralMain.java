package main;

public class GeneralMain {

	public void DragonMain() {
		
	}
	
	public void LoginMain() {
		
	}
	
	public void PwChange() {
		
	}
	
	public void SysOut() {
		
	}
	
	
}
