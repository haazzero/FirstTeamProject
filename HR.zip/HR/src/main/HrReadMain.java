package main;

public class HrReadMain {

	public void pmReader() {
		
	}
	
	public void emView() {
		
	}
	
	public void emList() {
		
	}
	
	public void emDtail(String) {
		
	}
	
	public void hisAllList() {
	}
	
	public void hisDetail(String) {
		
	}
	
	public void workView() {
		
	}
	
	public void workList() {
		
	}
	
	public void workDetail(String) {
		
	}
	
	public void yearList() {
		
	}
	
	public void yearDetail(String) {
		
	}
	
	public void salMain() {
		
	}
	
	public void salInfoList() {
		
	}
	
	
	public void salInfoDetail(String) {
		
	}
	
	
	public void salPayList() {
		
	}
	
	public void salPayDetail(String) {
		
	}
	
	public void revView() {
		
	}
	
	public void revList() {
		
	}
	
	
	public void revDetail(String) {
		
	}
		
}