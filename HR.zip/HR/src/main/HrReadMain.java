package main;

public class HrReadMain {

	public void PmReader() {
		
	}
	
	public void EmView() {
		
	}
	
	public void EmAllList() {
		
	}
	
	public void EmDtail(String) {
		
	}
	
	public void HisAllList() {
	}
	
	public void HisDetail(String) {
		
	}
	
	public void DnlView() {
		
	}
	
	public void DnlList() {
		
	}
	
	public void DnlDetail(String) {
		
	}
	
	public void YearList() {
		
	}
	
	public void YearDetail(String) {
		
	}
	
	public void SalMain() {
		
	}
	
	public void SalInfoList() {
		
	}
	
	
	public void SalInfoDetail(String) {
		
	}
	
	
	public void SalPayList() {
		
	}
	
	public void SalPayDetail(String) {
		
	}
	
	public void PrView() {
		
	}
	
	public void PrList() {
		
	}
	
	
	public void PrDetail(String) {
		
	}
		
}