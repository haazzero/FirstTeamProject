package main;

import java.util.Scanner;

import dao.EmployeeDAO;
import dao.HistoryDAO;
import dao.ReviewDAO;
import dao.SalaryDAO;
import dao.SalaryPaymentDAO;
import dao.WorkDAO;
import dao.YearDAO;
import vo.EmployeeVO;

public class AccountAdminMain {

	private Scanner sc;
	public static String id;
	private EmployeeDAO edao;
	private HistoryDAO hdao;
	private WorkDAO wdao;
	private YearDAO ydao;
	private SalaryDAO sdao;
	private SalaryPaymentDAO spdao;
	private ReviewDAO rdao;
	private EmployeeVO evo;

	public void adManage() {
		
	}
	
	public void salInfo() {
		
	}
	
	public void salInfoWrite() {
		
	}
	
	public void salInfoModify(String emid) {
		
	}
	
	public void salInfoRemove(String) {
		
	}
	
	public void salPayWrite() {
		
	}
	
	public void salPayModify(String) {
		
	}
	
	public void salPayRemove(String) {
		
	}
	
}
