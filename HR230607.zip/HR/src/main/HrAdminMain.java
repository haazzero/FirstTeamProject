package main;

import java.util.Scanner;

import dao.EmployeeDAO;
import dao.HistoryDAO;
import dao.ReviewDAO;
import dao.SalaryDAO;
import dao.SalaryPaymentDAO;
import dao.WorkDAO;
import dao.YearDAO;

public class HrAdminMain {
	
	private Scanner sc;
	public static String id;
	private EmployeeDAO edao;
	private HistoryDAO hdao;
	private WorkDAO wdao;
	private YearDAO ydao;
	private SalaryDAO sdao;
	private SalaryPaymentDAO spdao;
	private ReviewDAO rdao;

	public void pmMenu() {
	}
	
	
	public void emManage() {
		
	}
	
	public void emWrite() {
		
	}
	
	public void emModify(String) {
		
	}
	
	public void emRemove(String) {
		
	}
	
	public void historyWrite() {
		
	}
	
	public void historyModify(String) {
		
	}
	
	public void historyRemove(String) {
		
	}
	
	
	public void workManage() {
		
	}
	
	public void workWrite() {
		
	}
	
	public void workModify(String) {
		
	}
	
	public void workRemove(String) {
		
	}
	
	public void yearWrite() {
		
	}
	
	public void yearModify(String) {
	}
	
	public void yearRemove(String) {
		
	}
	
	public void revManage() {
		
	}
	
	public void revWrite() {
		
	}
	
	public void revModify(String) {
		
	}
	
	public void revRemove(String) {
		
	}	
	
	
}
