package main;

import java.util.Scanner;

import dao.HRSystemDAO;
import vo.HRSystemVO;

public class HRSystemMain {

	private Scanner sc;
	private HRSystemDAO hrsdao;
	private HRSystemVO hrsvo;
	
	public void dragonMain() {
		
	}
	
	public void login() {
		
	}
	
	public void pwChange() {
		
	}
	
	public void main(String[]) {
		
	}
	
	
}
