package util;

public class DBConn {

	private Connection con;
	
	private DBConn() {}
	
	public static Connection getConnection() {
		
	}
	
	public static void close(PreparedStatement pstmt) {
		
	}
	
	public static void close(PreparedStatement pstmt, ResultSet rs) {
		
	}
	
	
	
}
