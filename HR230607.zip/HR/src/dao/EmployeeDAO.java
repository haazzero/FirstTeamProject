package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import vo.EmployeeVO;

public class EmployeeDAO {

	private String query;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean emInsert(EmployeeVO) {
		
	}
	
	public List<EmployeeVO> emSelect() {
		
	}
	
	public List<EmployeeVO> emSelectD() {
		
	}
	
	
	public List<EmployeeVO> emSelectP() {
		
	}
	
	public EmployeeVO emSelect(String) {
		
	}
	
	public boolean emUpdate(EmployeeVO) {
		
	}
	
	public boolean emDelete(String) {
		
	}
	
}
