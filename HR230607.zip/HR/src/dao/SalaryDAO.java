package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class SalaryDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean salInsert(SalaryVO) {
      
   }
   
   public List<SalaryVO> salarySelect() {
      
   }
   
   public List<SalaryVO> salarySelectD() {
      
   }
   public SalaryVO salSelect(SalaryVO) {
      
   }
   public boolean salUpdate(SalaryVO) {
      
   }
   
   public boolean salDelete(String) {
      
   }
   
}