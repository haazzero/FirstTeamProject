package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import vo.HistoryVO;

public class HistoryDAO {

	private String query;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean hisInsert() {
		
	}
	
	public List<HistoryVO> hisSelect() {
		
	}
	
	public HistoryVO hisSelect(String) {
		
	}
	
	public boolean hisUpdate(String) {
		
	}
	
	
	public boolean hisDelete(String) {
		
	}
		
}
