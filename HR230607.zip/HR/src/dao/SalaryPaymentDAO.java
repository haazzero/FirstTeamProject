package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class SalaryPaymentDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean salPayInsert(SalaryPaymentVO) {
   
   }
   
   public List<SalaryPaymentVO> salPaySelect() {
      
   }
   
   public List<SalaryPaymentVO> salPaySelectD() {
      
   }
   
   public SalaryPaymentVO salPaySelect(String) {
      
   }
   
   public boolean salPayUpdate(SalaryPaymentVO) {
      
   }
   
   public boolean salDelete(SalaryPaymentVO) {
      
   }
      
}