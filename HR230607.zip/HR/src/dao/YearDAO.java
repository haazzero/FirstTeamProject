package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class YearDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean yearInsert(YearVO) {
      
   }
   
   public List<YearVO> yearSelecet() {
      
   }
   
   public List<YearVO> yearSelect(YearVO) {
      
   }
   
   public boolean yearUpdate(YearVO) {
      
   }
   
   public boolean yeardelete(String) {
      
   }
      
}