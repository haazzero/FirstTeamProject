package deco;

public class ScreenList2 {

	public static void HREA() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            MENU           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 정보 조회   2. 근태 조회 ");
		System.out.println("  3. 급여 조회        4. 인사고과 조회 ");
		System.out.println("  5. 시스템 종료");
		System.out.println();
	    System.out.println("  💡 선택 >> ");
	    System.out.println();
	    System.out.println("--------------------------------");
	   	System.out.println("     1번 ~ 5번을 선택해주세요.  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
	   	
		
	}
	
	public static void HREA1() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       직원 조회 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 전체 목록  2. 히스토리 목록");
		System.out.println("  3. 메인 메뉴                       ");  
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("     1번 ~ 3번을 선택해주세요.  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	public static void HREA2() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       직원 전체 목록      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println(" 사번 | 사원명 | 성별 | 생년월일 | 연락처 | 입사일자 | 부서번호 | 직급  | 주소");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println("      |        |      |          |        |          |          |       |       ");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println(" 1. 부서별 조회  2. 직급별 조회");
		System.out.println(" 3. 개별 조회    4. 직원조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택 >> ");
	    System.out.println();
		
		
	}
	
	public static void HREA2_1() {

		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║      부서별 직원 조회     ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 생산팀(D1)   2. 인사팀(D2)");
		System.out.println("  3. 품질관팀(D3) 4. 경리팀(D4) ");
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println(" 사번 | 사원명 | 성별 | 생년월일 | 연락처 | 입사일자 | 부서번호 | 직급  | 주소");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println("      |        |      |          |        |          |          |       |       ");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println();
        System.out.println("  1. 개별 조회  2. 직원 조회 메뉴"); 
        System.out.println();
        System.out.println("  💡 선택 >> ");
        System.out.println();
		
	}
	
	public static void HREA2_2() {

		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║      직급별 직원 조회     ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 사원   2. 대리");
		System.out.println("  3. 과장   4. 부장");
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println(" 사번 | 사원명 | 성별 | 생년월일 | 연락처 | 입사일자 | 부서번호 | 직급  | 주소");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println("      |        |      |          |        |          |          |       |       ");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println();
        System.out.println("  1. 개별 조회  2. 직원 조회 메뉴"); 
        System.out.println();
        System.out.println("  💡 선택 >> ");
        System.out.println();
		
	}
	
	public static void HREA3() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        직원 개별 조회     ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡사번을 입력하세요 >>  ");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println(" 사번 | 사원명 | 성별 | 생년월일 | 연락처 | 입사일자 | 부서번호 | 직급  | 주소");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println("      |        |      |          |        |          |          |       |       ");
        System.out.println("───────────────────────────────────────────────────────────────────────────────");
        System.out.println();
		System.out.println("  1. 정보 수정  2. 정보 삭제  3. 직원 조회 메뉴");
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
		
		
	}
	
	public static void HREA4() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     히스토리 전체 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println(" 사번 | 사원명 |               변동 사항                       ");
        System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println("      |        |                                               ");
        System.out.println("───────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println("  1. 개별 조회  2. 직원조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택 >> ");
	    System.out.println();
		
		
	}

	public static void HREA5() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     히스토리 개별 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 사번을 입력하세요 >>  ");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println(" NO.  |사번 | 사원명 |               변동 사항                       ");
        System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println("   1  |     |        |                                               ");
        System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println();
        System.out.println(" < 조회 하고 싶은 히스토리의 번호를 입력하세요 >");
        System.out.println("  💡 선택 >> ");
        System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println(" NO.  |사번 | 사원명 |               변동 사항                       ");
        System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println("   1  |     |        |                                               ");
        System.out.println("───────────────────────────────────────────────────────────────");
        System.out.println();
		System.out.println("  1. 정보 수정  2. 정보 삭제  3. 직원 조회 메뉴");
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
	    
	    
	    
	
	}

	public static void HREA6() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       근태 조회 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 근태 기록 목록  ");
	    System.out.println("  2. 연차 승인 내역 목록");
		System.out.println("  3. 메인 메뉴                        ");  
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("     1번 ~ 3번을 선택해주세요.  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
	
	}

	public static void HREA7() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     근태기록 전체 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println(" 사번 | 사원명 | 지각일수 |  조퇴일수 | 결근일수 | 사용가능연차일수 | 사용연차이수 | 잔여연차일수                ");
    	System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println("      |        |          |           |          |                  |              |               ");
    	System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println("  1. 개별 조회  2. 근태조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택 >> ");
	    System.out.println();
		
	
	}

		public static void HREA8() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    근태 기록 개별 조회    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  💡 사번을 입력하세요 >>  ");
			System.out.println();
			System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
	        System.out.println(" 사번 | 사원명 | 지각일수 |  조퇴일수 | 결근일수 | 사용가능연차일수 | 사용연차이수 | 잔여연차일수                ");
	    	System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
	        System.out.println("      |        |          |           |          |                  |              |               ");
	    	System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
	    	System.out.println();
	    	System.out.println("  1. 근태 기록 수정  2. 근태 기록 삭제  3. 근태 조회 메뉴");
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
		}

		public static void HREA9() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    연차 승인 내역 목록    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("──────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 직원이름 | 연차사용날짜 | 연차사용일수 | 연차승인자 | 연차승인일자");
			System.out.println("──────────────────────────────────────────────────────────────────────────────────");
			System.out.println("          |          |              |              |            |         ");
			System.out.println("──────────────────────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
			System.out.println();
			System.out.println("  1. 개별 조회  2. 근태 조회 메뉴");
		    System.out.println();
		    System.out.println("  💡 선택 >> ");
		    System.out.println();
		
	
		}

		public static void HREA10() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    연차 승인 내역 조회    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  💡 사번을 입력하세요 >>  ");
			System.out.println();
			System.out.println("──────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 직원이름 | 연차사용날짜 | 연차사용일수 | 연차승인자 | 연차승인일자");
			System.out.println("──────────────────────────────────────────────────────────────────────────────────");
			System.out.println("          |          |              |              |            |             ");
			System.out.println("──────────────────────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println("  1. 연차 승인 내역 수정  2. 연차 승인 내역 삭제  3. 근태 조회 메뉴");
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
	
		}

		public static void HREA11() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║       급여 조회 메뉴      ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  1.급여 정보 전체 목록");
			System.out.println("  2.급여 지급 내역 전체 목록");
			System.out.println("  3.메인메뉴");                     
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
			System.out.println("--------------------------------");
		   	System.out.println("     1번 ~ 3번을 선택해주세요.  ");
		   	System.out.println("--------------------------------");
		   	System.out.println();
	
		}

		public static void HREA12() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║     급여정보 전체 목록    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("─────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 직원이름 | 기본급(호봉) | 은행명 | 예금주 | 계좌번호");
			System.out.println("─────────────────────────────────────────────────────────────────");
			System.out.println("          |          |              |        |        |         ");
			System.out.println("─────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
			System.out.println();
			System.out.println("  1. 내림차순 보기(기본급)  2. 개별 조회  3. 급여 조회 메뉴");
		    System.out.println();
		    System.out.println("  💡 선택 >> ");
		    System.out.println();
		}
		
		public static void HREA13() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║     급여정보 상세 조회    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  💡 사번을 입력하세요 >>  ");
			System.out.println();
			System.out.println("─────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 직원이름 | 기본급(호봉) | 은행명 | 예금주 | 계좌번호");
			System.out.println("─────────────────────────────────────────────────────────────────");
			System.out.println("          |          |              |        |        |         ");
			System.out.println("─────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println();
			System.out.println("  1. 급여 정보 수정  2. 급여 정보 삭제  3. 급여 조회 메뉴");
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
		}
		
		public static void HREA14() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    급여 지급 내역 목록    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("──────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 지급일시 | 기본급(호봉) | 상여금 | 총급여 ");
			System.out.println("──────────────────────────────────────────────────────");
			System.out.println("          |          |              |        |        ");
			System.out.println("──────────────────────────────────────────────────────");
			System.out.println();
			System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
			System.out.println();
			System.out.println("  1. 내림차순 보기(기본급)  2. 개별 조회  3. 급여 조회 메뉴");
		    System.out.println();
		    System.out.println("  💡 선택 >> ");
		    System.out.println();
		   
			
		}
		
		public static void HREA15() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    급여 지급 내역 조회    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  💡 사번을 입력하세요 >>  ");
			System.out.println();
			System.out.println("──────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 지급일시 | 기본급(호봉) | 상여금 | 총급여 ");
			System.out.println("──────────────────────────────────────────────────────");
			System.out.println("          |          |              |        |        ");
			System.out.println("──────────────────────────────────────────────────────");
			System.out.println();
			System.out.println();
			System.out.println("  1. 급여 지급 내역 수정  2. 급여 지급 내역 삭제  3. 급여 조회 메뉴");
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
			
		}
		
		public static void HREA16() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║     인사 고과 조회 메뉴   ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  1. 평가기록 전체 목록");
			System.out.println("  2. 평가기록 개별 조회");
			System.out.println("  3. 메인메뉴");                     
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
			System.out.println("--------------------------------");
		   	System.out.println("     1번 ~ 3번을 선택해주세요.  ");
		   	System.out.println("--------------------------------");
		   	System.out.println();
			
		}
		
		public static void HREA17() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║     인사고과 전체 목록    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 | 비고 |평가일시");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println("          |          |      |           |         |        |        |          |      |            |       |");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
			System.out.println();
			System.out.println(" 1. 부서별 조회  2. 직급별 조회");
			System.out.println(" 3. 연도별 조회  4. 개별 조회");
			System.out.println(" 5. 인사고과 조회 메뉴");
		    System.out.println();
		    System.out.println("  💡 선택 >> ");
		    System.out.println();
			
		}
		
		public static void HREA17_1() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    부서별 인사고과 조회   ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  1. 생산팀(D1)   2. 인사팀(D2)");
			System.out.println("  3. 품질관팀(D3) 4. 경리팀(D4) ");
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 | 비고 |평가일시");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println("          |          |      |           |         |        |        |          |      |            |       |");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
	        System.out.println();
	        System.out.println("  💡 선택 >> ");
	        System.out.println();
			
		}
		
		public static void HREA17_2() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    직급별 인사고과 조회   ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  1. 사원   2. 대리");
			System.out.println("  3. 과장   4. 부장");
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 | 비고 |평가일시");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println("          |          |      |           |         |        |        |          |      |            |       |");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
	        System.out.println();
	        System.out.println("  💡 선택 >> ");
	        System.out.println();
			
		}

		public static void HREA17_3() {
			System.out.println("  ╔══════════════════════════════╗");  // 2칸씩
			System.out.println("  ║      연도별 인사고과 조회    ║");
			System.out.println("  ╠══════════════════════════════║");
			System.out.println("  ║ 기록은 평가일로부터 3년 유효 ║");
			System.out.println("  ╚══════════════════════════════╝");
			System.out.println();
			System.out.println("  💡 연도를 입력하세요 >>  ");
			System.out.println();
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 | 비고 |평가일시");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println("          |          |      |           |         |        |        |          |      |            |       |");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println("  1. 개별 조회   2. 인사고과 조회 메뉴"); 
	        System.out.println();
	        System.out.println("  💡 선택 >> ");
	        System.out.println();
	
		}
		
		public static void HREA18() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║     인사고과 상세 조회    ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  💡 사번을 입력하세요 >>  ");
			System.out.println();
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" NO.| 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 | 비고 |평가일시");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println("  1 |          |          |      |           |         |        |        |          |      |            |       |");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println();
			System.out.println(" < 조회 하고 싶은 기록의 번호를 입력하세요 >");
	        System.out.println("  💡 선택 >> ");
	        System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println(" NO.| 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 | 비고 |평가일시");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.println("  1 |          |          |      |           |         |        |        |          |      |            |       |");
			System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
	        System.out.println();
			System.out.println("  1. 평가 수정  2. 평가 삭제  3. 인사고과 조회 메뉴");
			System.out.println();
			System.out.println("  💡 선택 >> ");
			System.out.println();
			
		}
		
	
	
	public static void main(String[] args) {

		HREA16();
		HREA17();
		HREA17_1();
		HREA17_2();
		HREA17_3();
		HREA18();
		
		

	}

}
