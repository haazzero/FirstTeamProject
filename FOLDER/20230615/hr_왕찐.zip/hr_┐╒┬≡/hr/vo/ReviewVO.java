package hr.vo;

public class ReviewVO {

	private String emid;		//	직원번호
	private String name;		//	직원이름
	private String dno;			//	부서번호
	private String dname;       //  부서이름
	private String position;	//	직급
	private int reno;			//  평가번호
	private int eval1;			//	평가항목1
	private int eval2;			//	평가항목2
	private int eval3;			//	평가항목3
	private int eval4;			//	평가항목4
	private int eval5;			//	평가항목5
	private int evalTot;		//	평가 총점수
	private String grade;  		//	평가 등급
	private String remark;		//	비고
	private String evalDate;	//	평가일자   yyyy-mm-dd
	
	public ReviewVO() {
		
	}
		
	
	public ReviewVO(String emid, String name, String dno, String dname, String position, int reno, int eval1, int eval2,
			int eval3, int eval4, int eval5, int evalTot, String grade, String remark, String evalDate) {
		super();
		this.emid = emid;
		this.name = name;
		this.dno = dno;
		this.dname = dname;
		this.position = position;
		this.reno = reno;
		this.eval1 = eval1;
		this.eval2 = eval2;
		this.eval3 = eval3;
		this.eval4 = eval4;
		this.eval5 = eval5;
		this.evalTot = evalTot;
		this.grade = grade;
		this.remark = remark;
		this.evalDate = evalDate;
	}
	public String getDno() {
		return dno;
	}
	public void setDno(String dno) {
		this.dno = dno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	
	public int getReno() {
		return reno;
	}
	public void setReno(int reno) {
		this.reno = reno;
	}
	public String getEmid() {
		return emid;
	}
	public void setEmid(String emid) {
		this.emid = emid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEval1() {
		return eval1;
	}
	public void setEval1(int eval1) {
		this.eval1 = eval1;
	}
	public int getEval2() {
		return eval2;
	}
	public void setEval2(int eval2) {
		this.eval2 = eval2;
	}
	public int getEval3() {
		return eval3;
	}
	public void setEval3(int eval3) {
		this.eval3 = eval3;
	}
	public int getEval4() {
		return eval4;
	}
	public void setEval4(int eval4) {
		this.eval4 = eval4;
	}
	public int getEval5() {
		return eval5;
	}
	public void setEval5(int eval5) {
		this.eval5 = eval5;
	}
	public int getEvalTot() {
		return evalTot;
	}
	public void setEvalTot(int evalTot) {
		this.evalTot = evalTot;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getEvalDate() {
		return evalDate;
	}
	public void setEvalDate(String evalDate) {
		this.evalDate = evalDate;
	}


	


	
	
	
	
}