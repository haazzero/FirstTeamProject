package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import hr.util.DBConn;
import hr.vo.ReviewVO;

public class ReviewDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   // 평가 등록
   public boolean revInsert(ReviewVO revo) {
	   try { 						 // 쿼리를 실행하다가 예외가 발생할 수 있으니까 try/ catch문에다가 	
		   query = " INSERT INTO REVIEW VALUES (SEQ_REVIEW_REVIEW_NO.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";			// insert 쿼리문, 평가를 등록하면 
		   

		   pstmt = DBConn.getConnection().prepareStatement(query);
		
		   pstmt.setString(1, revo.getEmid());
		   pstmt.setInt(2, revo.getEval1());
		   pstmt.setInt(3, revo.getEval2());
		   pstmt.setInt(4, revo.getEval3());
		   pstmt.setInt(5, revo.getEval4());
		   pstmt.setInt(6, revo.getEval5());
		   pstmt.setInt(7, revo.getEvalTot());
		   pstmt.setString(8, revo.getGrade());
		   pstmt.setString(9, revo.getRemark());
		   pstmt.setString(10, revo.getEvalDate());
		 
		     
		   int result = pstmt.executeUpdate();
		 
		   if(result ==1) {   // 정상적으로 등록 성공시 true 반환
			  return true; }
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		}finally {   
	  		 DBConn.close(pstmt);
	  		}
	  		// 그렇지 않으면  false 반환
	  		return false;	  	   	
      
   } // revInsert end
   
   // 평가 전체 목록 
   public List<ReviewVO> revSelect() {
	    List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"    // 조인을 사용하여 원하는 컬럼만 가져와서 출력한다.
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " ORDER BY r.review_no ASC";									// 시퀀스 번호대로 오름차순 정렬한다.
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while  반복해서 출력
				revo = new ReviewVO();   // ReviewVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가 vo값을 list에 넣기
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}	
		return reviewList;   // 리스트를 반환
	    	
      
   } // revInsert(ReviewVO revo) end
   
   // 평가 부서별
   public List<ReviewVO> revSelectD(String dno) {
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"    // 전체 출력과 출력하고 싶은 컬럼은 같다. 조인 사용
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND d.dno = ?"															// 부서별 출력이니 부서를 ?로 받는다.
					+ " ORDER BY r.review_no ASC";		
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1, dno);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
 			e.printStackTrace();
 		}finally { 
 		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
 		}	
		return reviewList;
      
   }
   
   // 평가 직급별
   public List<ReviewVO> revSelectP(String position) {
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND e.position = ?"												// 직급별 출력이니 position을 ?로 받는다.
					+ " ORDER BY r.review_no ASC";
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1, position);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { 
		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}	
		return reviewList;
     
      
   }
   
   // 평가 연도별
   public List<ReviewVO> revSelectY(String evaldate) {
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND substr(r.eval_date,1,4) = ?"							// 연도를 ?로 받는다. 여기서 내가 필요한건 yyyy-mm-dd 중에 yyyy이기 때문에
					+ " ORDER BY r.review_no ASC";									// eval_date에서 yyyy만 가져온다.
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1,evaldate );
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { 
		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}	
		return reviewList;
    
      
   }
   
   // 평가 개인조회
   public List<ReviewVO> revSelect(String emid) {
	   
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.eval1, r.eval2,"					// 개인조회에서는 출력한 컬럼이 많다.
					+ " r.eval3, r.eval4, r.eval5,r.eval_tot,r.grade,r.remark, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND e.emid = ?"																		// 개인조회이니까 입력받은 직원번호에 따라서 해당하는 값을 출력.
					+ " ORDER BY r.review_no ASC";
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1, emid);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setEval1(rs.getInt("eval1"));
				revo.setEval2(rs.getInt("eval2"));
				revo.setEval3(rs.getInt("eval3"));
				revo.setEval4(rs.getInt("eval4"));
				revo.setEval5(rs.getInt("eval5"));
				revo.setEvalTot(rs.getInt("eval_tot"));
				revo.setGrade(rs.getString("grade"));	
				revo.setRemark(rs.getString("remark"));
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { 
		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}	
		return reviewList;
	
      
   }
   
   // 평가 상세 조회
   public ReviewVO revSelect(int rno) {
	   ReviewVO revo = null;
	   
		try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.eval1, r.eval2,"
					+ " r.eval3, r.eval4, r.eval5,r.eval_tot,r.grade,r.remark, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND r.review_no = ?"											// 개인조회에서 나온 여러 결과 값중에 시퀀스 번호를 입력받아 해당하는 값 가져옴.
					+ " ORDER BY r.review_no ASC";    //쿼리문 아이디 조회하는
			pstmt = DBConn.getConnection().prepareStatement(query);// 실행할 prepared
		
			pstmt.setInt(1,rno); // 물음표 바인딩   // 여기서 넘어온 mid
		
			rs = pstmt.executeQuery();  // 실행한다.  executeQuery 는 resultSet 으로 온다. 그래서 int로 받을 수 없다. 결과가 있기 때문에 
		
		
			if(rs.next()) {		// 조회된 레코드가 있다면  // == true 기본
				revo = new ReviewVO();   // ReviewVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setEval1(rs.getInt("eval1"));
				revo.setEval2(rs.getInt("eval2"));
				revo.setEval3(rs.getInt("eval3"));
				revo.setEval4(rs.getInt("eval4"));
				revo.setEval5(rs.getInt("eval5"));
				revo.setEvalTot(rs.getInt("eval_tot"));
				revo.setGrade(rs.getString("grade"));	
				revo.setRemark(rs.getString("remark"));
				revo.setEvalDate(rs.getString("eval_date"));
		}
		}catch (SQLException e) {
 			e.printStackTrace();
 		}finally { 
 			DBConn.close(rs, pstmt);
 		 
 		}
		return revo;
		
	   
   }
   
   // 평가 수정
   public boolean revUpdate(ReviewVO revo) {
	   try {   
		   																				// 시퀀스 번호에 따라 set 뒤에 물음표 값에 새로 입력받은 값 저장
		   query = " UPDATE review SET eval1=?, eval2 =?, eval3=?, eval4=?, eval5=?, eval_tot=?, grade=?, remark = ? WHERE review_no = ?";
		   	   
		   pstmt = DBConn.getConnection().prepareStatement(query);	   
		   
		   pstmt.setInt(1, revo.getEval1());
		   pstmt.setInt(2, revo.getEval2());
		   pstmt.setInt(3, revo.getEval3());
		   pstmt.setInt(4, revo.getEval4());
		   pstmt.setInt(5, revo.getEval5());
		   pstmt.setInt(6, revo.getEvalTot());
		   pstmt.setString(7, revo.getGrade());
		   pstmt.setString(8, revo.getRemark());
		   pstmt.setInt(9, revo.getReno());
		   
		  
		   int result = pstmt.executeUpdate();
		 
		   if(result ==1) {   // 정상적으로 수정 성공 시 true 반환
			  return true; }
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		}finally {   
	  		 DBConn.close(pstmt);
	  		}
	  		// 그렇지 않으면  false 반환
	  		return false;	  
      
   }
   
   // 평가 삭제
   public boolean revDelete(int reno) {
	   try {
			  query = "DELETE FROM review WHERE review_no = ? ";     // 시퀀스 번호를 입력받아 해당하는 값 삭제.
			  
			  pstmt = DBConn.getConnection().prepareStatement(query);
			  pstmt.setInt(1, reno);
			  
			  
			  	int result = pstmt.executeUpdate();
			  	
			  	 if(result ==1) { 
			  		 return true;
					   }
			  		} catch (SQLException e) {
			  			e.printStackTrace();
			  		}finally {   
			  		 DBConn.close(pstmt);
			  		}
			  		// 그렇지 않으면  false 반환
			  		return false ;	   
      
   }
   
   // 평가 연도 조회 후 전체 삭제
   public boolean revyearDelete(String year) {
	   try {
			  query = "DELETE FROM review WHERE substr(eval_date,1,4) = ?  ";     // 입력받은 yyyy를 where절에 넣고 해당하는 데이터 삭제
			  
			  pstmt = DBConn.getConnection().prepareStatement(query);
			  pstmt.setString(1, year);
			  
			  
			  	int result = pstmt.executeUpdate();
			  	
			  	 if(result ==1) { 
			  		 return true;
					   }
			  		} catch (SQLException e) {
			  			e.printStackTrace();
			  		}finally {   
			  		 DBConn.close(pstmt);
			  		}
			  		// 그렇지 않으면  false 반환
			  		return false ;	  
   }
   
   
   
   
} // class end