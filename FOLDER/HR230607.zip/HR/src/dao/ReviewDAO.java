package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class ReviewDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean revInsert(ReviewVO) {
      
   }
   
   public List<ReviewVO> revSelecet() {
      
   }
   
   public List<ReviewVO> revSelectD() {
      
   }
   
   public List<ReviewVO> revSelectP() {
      
   }
   
   public List<ReviewVO> revSelectY() {
      
   }
   
   public ReviewVO revSelect(String) {
      
   }
   
   public boolean revUpdate(ReviewVO) {
      
   }
   
   public boolean revDelete(String) {
      
   }
   
}