package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HRSystemDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean pwUpdate(HRSystEmployeeVO) {
      
   }
   
   public boolean loginChck(String, String) {
	   
   }
   
   
   
}