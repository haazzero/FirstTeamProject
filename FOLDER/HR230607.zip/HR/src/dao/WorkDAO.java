package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import vo.WorkVO;

public class WorkDAO {

	private String query;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean workInsert(WorkVO) {
		
	}
	
	public List<WorkVO> WorkSelect() {
		
	}
	
	public WorkVO WorkSelect(String) {
		
	}
	
	public boolean WorkUpdate(WorkVO) {
		
	}
	public boolean WorkDelete(String) {
		
	}
	
	
}
