package deco;

public class ScreenList3 {

	public static void AADM () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            MENU           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 급여 정보  2. 급여 지급내역  ");
		System.out.println("  3. 메인메뉴   4. 시스템 종료  ");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
	    System.out.println("--------------------------------");
	   	System.out.println("    1번 ~ 4번을 선택해주세요.   ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
	}
	
	public static void AADM1 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 급여 정보 등록  2. 급여 정보 전체");
		System.out.println("  3. 급여 관리 메뉴  ");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("    1번 ~ 3번을 선택해주세요.   ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	public static void AADM2 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     급여 지급 내역 메뉴   ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 급여 지급내역 등록 ");
		System.out.println("  2. 급여 지급내역 전체 목록");
		System.out.println("  3. 급여 관리 메뉴  ");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("    1번 ~ 3번을 선택해주세요.   ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}

	public static void AADM3 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 등록      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 급여 정보 등록을 위한 정보를 입력해주세요.>");
		System.out.println();
		System.out.println("  1.직원 번호 >>");
		System.out.println("  2.은행 이름 >>");
		System.out.println("  3.예금주 >>");
		System.out.println("  4.계좌번호 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      등록이 완료되었습니다.     ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("    정보 등록에 실패했습니다.    ");
		System.out.println("--------------------------------");
		System.out.println();
	
	}

	public static void AADM4 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 수정      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.은행이름  >>");
		System.out.println("  2.예금주 >>");
		System.out.println("  3.계좌번호 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      정보가 수정되었습니다.    ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("      수정에 실패했습니다.      ");
	   	System.out.println("--------------------------------");
		System.out.println();
	
	}

	public static void AADM5 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 삭제      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("         삭제되었습니다.          ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         취소되었습니다.          ");
	   	System.out.println("--------------------------------");
		System.out.println();
	
	}

	public static void AADM6 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    급여 지급 내역 등록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 급여 정보 등록을 위한 정보를 입력해주세요.>");
		System.out.println();
		System.out.println("  1.직원 번호 >>");
		System.out.println("  2.지급일시 >>");
		System.out.println("  3.기본급 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      등록이 완료되었습니다.     ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("    정보 등록에 실패했습니다.    ");
		System.out.println("--------------------------------");
		System.out.println();
	
	
	}
	
	public static void AADM7 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     급여 지급 내역 수정   ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.지급일시 >>");
		System.out.println("  2.기본급 >>");
		System.out.println("  3.상여금 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      정보가 수정되었습니다.    ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("      수정에 실패했습니다.      ");
	   	System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	public static void AADM8 () {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     급여 지급 내역 삭제   ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("         삭제되었습니다.          ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         취소되었습니다.          ");
	   	System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	
	
	public static void main(String[] args) {
		
       AADM(); 
       AADM1(); 
       AADM2(); 
	}

}
