package deco;

public class ScreenList {
	
	public static void gen1() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            Main           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    1. 로그인     2. 시스템 종료   ");
		System.out.println();
	   	System.out.println("    💡 선택 >>  ");
	   	System.out.println();
	   	System.out.println("--------------------------------");
	   	System.out.println("       1번이나 2번을 선택하세요.     ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	
	public static void gen2() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║           LOGIN           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    💡 아이디 >>  ");
		System.out.println();
		System.out.println("    💡 비밀번호 >>  ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("  잘못된 입력입니다. 다시 입력해주세요  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	
	public static void gen3() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║      Change Password      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 변경할 비밀번호 입력 (숫자 4자리)");
	    System.out.println("  >> ");
	    System.out.println("--------------------------------");
	    System.out.println("     비밀번호 변경이 완료되었습니다.   ");
	    System.out.println("--------------------------------");
	    System.out.println("--------------------------------");
	    System.out.println(" 비밀번호 변경에 실패했습니다. 다시 입력해주세요.");
	    System.out.println("--------------------------------");
	    System.out.println();
	
	}
	
	
	public static void gen4() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        SYSTEM EXIT        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 시스템을 종료하시겠습니까? ( Y | N )");
		System.out.println("  💡 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("        시스템이 종료되었습니다.     ");
		System.out.println("--------------------------------");
	
	}
	
	public static void HADM() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            MENU           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 관리 2. 근태 관리 3. 급여 조회   ");
		System.out.println("  4. 인사고과 관리  5. 시스템 종료 ");
	    System.out.println();
	    System.out.println("  💡 선택 >> ");
	    System.out.println();
	    System.out.println("--------------------------------");
	   	System.out.println("       1번 ~ 5번을 선택해주세요.     ");
	   	System.out.println("--------------------------------");
		
	}
	
	public static void HADM1() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        직원 관리 메뉴        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 정보 등록  2. 직원 전체 목록");
		System.out.println("  3. 히스토리 등록   4. 히스토리 목록");
		System.out.println("  5. 메인 메뉴 ");
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("       1번 ~ 5번을 선택해주세요.     ");
	   	System.out.println("--------------------------------");
		
	}
	
	public static void HADM2() {
		System.out.println("  ╔═════════════════════════════╗");  // 2칸씩
		System.out.println("  ║         직원 정보 등록         ║");
		System.out.println("  ╠═════════════════════════════║");
		System.out.println("  ║(예시)                        ║");
		System.out.println("  ║생년월일 >> YY.MM.DD           ║");
		System.out.println("  ║연락처　>> 010-0000-0000       ║");
		System.out.println("  ║성별 >> 여성 | 남성             ║");
		System.out.println("  ║입사일자 >> YY.MM.DD           ║");
		System.out.println("  ║직급 >> 사원 | 대리 | 과장 | 부장 ║");
		System.out.println("  ╚═════════════════════════════╝");
		System.out.println();
		System.out.println("  < 등록할 직원의 정보를 입력해주세요> ");
		System.out.println();
		System.out.println("   사원명 >> ");
		System.out.println("   생년월일 >> ");
		System.out.println("   연락처 >> ");
		System.out.println("   성별 >> ");
		System.out.println("   주소 >> ");
		System.out.println("   사번 >> ");
		System.out.println("   입사일자 >> ");
		System.out.println("   부서 번호 >> ");
		System.out.println("   직급 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("    입력하신 정보가 저장되었습니다.    ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("     직원관리 메뉴로 돌아갑니다.      ");
	   	System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("      정보 등록에 실패했습니다. "     );
	   	System.out.println("--------------------------------");
		
		
	}
	
	public static void HADM3() {
		System.out.println("  ╔═════════════════════════════╗");  // 2칸씩
		System.out.println("  ║         직원 정보 수정         ║");
		System.out.println("  ╠═════════════════════════════║");
		System.out.println("  ║(예시)                        ║");
		System.out.println("  ║생년월일 >> YY.MM.DD           ║");
		System.out.println("  ║연락처　>> 010-0000-0000       ║");
		System.out.println("  ║성별 >> 여성 | 남성             ║");
		System.out.println("  ║입사일자 >> YY.MM.DD           ║");
		System.out.println("  ║직급 >> 사원 | 대리 | 과장 | 부장 ║");
		System.out.println("  ╚═════════════════════════════╝");
		System.out.println();
		System.out.println("        < 정보를 수정하세요.>");
		System.out.println();
		System.out.println("  사번 >> ");
		System.out.println("  입사일자 >> ");
		System.out.println("  부서 번호 >> ");
		System.out.println("  직급 >> ");
		System.out.println("  사원명 >> ");
		System.out.println("  생년월일 >> ");
		System.out.println("  연락처 >> ");
		System.out.println("  성별 >> ");
		System.out.println("  주소 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("        정보가 수정되었습니다.       ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("     직원관리 메뉴로 돌아갑니다.      ");
	   	System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         수정에 실패했습니다.       ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	public static void HADM4() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        직원 정보 삭제        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("------------------------------------");
		System.out.println("  삭제되었습니다. 직원관리 메뉴로 돌아갑니다.");  //자동연결 메뉴불러오기
		System.out.println("------------------------------------");
		System.out.println("------------------------------------");
		System.out.println("  취소되었습니다. 직원관리 메뉴로 돌아갑니다."); //자동연결 메뉴불러오기
		System.out.println("------------------------------------");
		System.out.println();
	}
	
    public static void HADM5() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║         히스토리 등록        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("   💡 사원 번호를 입력해주세요 >> ");
		System.out.println();
		System.out.println("   💡 등록하실 내용을 입력해주세요.");
		System.out.println("   💡 >>  ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("        등록이 완료되었습니다.       ");
	   	System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("         등록에 실패했습니다.       ");
	 	System.out.println("--------------------------------");
	
		
		
		
		
	}
    
    public static void HADM6() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║         히스토리 수정        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("      수정할 내용을 입력해주세요  ");
		System.out.println();
		System.out.println("      💡 입력 >>"       );
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("       히스토리가 수정되었습니다.     ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         수정에 실패했습니다.       ");
	   	System.out.println("--------------------------------");
		
	}
    
    public static void HADM7() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║         히스토리 삭제        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("------------------------------------");
		System.out.println("  삭제되었습니다. 직원관리 메뉴로 돌아갑니다.");  //자동연결 메뉴불러오기
		System.out.println("------------------------------------");
		System.out.println("------------------------------------");
		System.out.println("  취소되었습니다. 직원관리 메뉴로 돌아갑니다."); //자동연결 메뉴불러오기
		System.out.println("------------------------------------");
    }
    
    public static void HADM8() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        근태 관리 메뉴        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 근태 기록 등록  2. 근태 기록 목록");
		System.out.println("  3. 연차 승인 등록  4. 연차 승인내역 목록 ");
		System.out.println("  5. 메인메뉴");
		System.out.println();
		System.out.println("  💡 선택 >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("       1번 ~ 5번을 선택해주세요.     ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
    	
    }

    public static void HADM9() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        근태 기록 등록        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 근태 기록을 위한 정보를 입력해주세요.>");
		System.out.println();
		System.out.println("  1.근속년수 >>");
		System.out.println("  2.지각일수 >>");
		System.out.println("  3.조퇴일수 >>");
		System.out.println("  4.결근일수 >>");
		System.out.println("  5.사용가능 연차일수 >>");
		System.out.println("  6.사용연차일수 >>");
		System.out.println("  7.잔여연차일수 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("        등록이 완료되었습니다.      ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("       정보 등록에 실패했습니다.     ");
		System.out.println("--------------------------------");
		System.out.println();
	
    }

    public static void HADM10() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        근태 기록 수정        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.근속년수 >>");
		System.out.println("  2.지각일수 >>");
		System.out.println("  3.조퇴일수 >>");
		System.out.println("  4.결근일수 >>");
		System.out.println("  5.사용가능 연차일수 >>");
		System.out.println("  6.사용연차일수 >>");
		System.out.println("  7.잔여연차일수 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("       근태 기록이 수정되었습니다.    ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         수정에 실패했습니다.       ");
	   	System.out.println("--------------------------------");
	
    }

    public static void HADM11() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        근태 기록 삭제        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("           삭제되었습니다.          ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("           취소되었습니다.          ");
	   	System.out.println("--------------------------------");
		
		
	
}

    public static void HADM12() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        연차 승인 등록        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 등록할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.직원번호 >> ");
		System.out.println("  2.연차사용날짜 >> ");
		System.out.println("  3.연차사용일수 >> ");
		System.out.println("  4.연차승인자 >> ");
		System.out.println("  5.연차승인일자 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("           등록되었습니다.          ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("         정보등록에 실패했습니다.     ");
		System.out.println("--------------------------------");
		System.out.println();
		
		
	
}

    public static void HADM13() {
	
}

    public static void HADM14() {
	
}

    public static void HADM15() {
	
}
    
    
    
    
	public static void main(String[] args) {

//		System.out.println("--------------------------------");
//		System.out.println("  💡 시스템을 종료하시겠습니까? ( Y | N )");
//		System.out.println("  💡 >> ");
//		System.out.println("--------------------------------");
//	   	System.out.println("       1번이나 2번을 선택하세요.     ");
//	   	System.out.println("--------------------------------");
		HADM11();
		HADM12();
		
	}

}
